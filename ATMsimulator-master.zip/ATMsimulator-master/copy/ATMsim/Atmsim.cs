using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace ATM
{
    class AtmSim
    {
        public Account[] acc;

        public Account activeAccount = null;
        public ATM prog;



        public AtmSim(Account[] acc)
        {
            this.acc = acc;

          
        }

       

        public void checkbal()
        {
            
                Label bal = new Label();
                bal.Location = new Point();
                bal.Text = " £" + activeAccount.getBalance();
                prog.panel1.Controls.Clear();
                prog.panel1.Controls.Add(bal);
            
        }
        public void withdraw(int amount)
        {
            int amountx;
            if (amount > 0)
            {
                activeAccount.decrementBalance(amount);

                Console.WriteLine("withdrawal succesful");

            }

        }
        public void deposit(int depo)
        {
            if (depo > 0)
            {
                activeAccount.setBalance(+depo);
            }
        }

        public void prefferences()
        {
        }

        public void more()
        {
        }

    }
}