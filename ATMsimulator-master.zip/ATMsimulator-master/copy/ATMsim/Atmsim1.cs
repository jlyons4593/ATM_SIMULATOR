﻿namespace ATM
{
    internal class Atmsim
    {
    }
}