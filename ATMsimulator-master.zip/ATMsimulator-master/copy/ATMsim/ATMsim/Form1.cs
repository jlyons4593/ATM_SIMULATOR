﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATM
{
    public partial class ATM : Form
    {
        private TextBox enteracc = new TextBox();
        private TextBox enterpin = new TextBox();
        private Label[,] option = new Label[3, 2];
        //account class call
        Account[] acc = new Account[3];
        private Label[,] w_disp = new Label[3, 2];
        //atmsim class call
        private AtmSim Sim;
        public int result;
        int accounts = 3;
        Boolean authentication;
        bool withdraw;
        int amount_withdraw;

        string inputText = "";
        string entred_pin = "";

        public ATM()
        {
            InitializeComponent();
            acc[0] = new Account(300, 1111, 111111);
            acc[1] = new Account(750, 2222, 222222);
            acc[2] = new Account(3000, 3333, 333333);

            Sim = new AtmSim(acc);
            authentication = false;
        }
        public void Form1_Load(object sender, EventArgs e)
        {
            programLoop();
        }

        private void programLoop()
        {


        }
        /*
        private void create_buttons()
        {
            Button[,] buttons = new Button[3, 2];
            Button[,] cell = new Button[4, 3];
            int x;
            int y = 20;
            int borderX;
            int borderY = 310;
            //telling the game that the first turn will be for black
            int counter = 1;
            //nested forloops to cycle through the tiles
            for (int i = 0; i < 4; i++)
            {
                borderX = 230;
                for (int j = 0; j < 3; j++)
                {
                    //initialising tiles 
                    cell[i, j] = new Button();
                    cell[i, j].Size = new Size(75, 65);
                    cell[i, j].Location = new Point(borderX, borderY);
                    //making default color of each tile blue
                    cell[i, j].BackColor = Color.LightGray;
                    cell[i, j].Name = Convert.ToString(counter);
                    cell[i, j].Text = Convert.ToString(counter);
                    if (counter == 10)
                    {
                        cell[i, j].Name = "empty";
                        cell[i, j].Text = "";
                    }
                    else if (counter == 11)
                    {
                        cell[i, j].Name = "0";
                        cell[i, j].Text = "0";
                    }
                    else if (counter == 12)
                    {
                        cell[i, j].Name = "enter";
                        cell[i, j].Text = "a";
                        cell[i, j].BackColor = Color.Green;
                        cell[i, j].Font = new Font("webdings", 18);
                        cell[i, j].Click += new EventHandler(this.btnenter_Click);
                    }
                    //cell[i, j].Click += new EventHandler(this.btnEvent_Click);
                    cell[i, j].Enabled = true;

                    Controls.Add(cell[i, j]);
                    counter++;
                    borderX += 76;
                }
                borderY += 66;

            }

            for (int i = 0; i < 3; i++)
            {
                x = 50;
                for (int j = 0; j < 2; j++)
                {
                    buttons[i, j] = new Button();
                    buttons[i, j].Size = new Size(100, 50);
                    buttons[i, j].Location = new Point(x, y);
                    //making default color of each tile blue
                    buttons[i, j].BackColor = Color.LightGray;
                    //buttons[i, j].Name = ;
                    if (x < 240)
                    {
                        buttons[i, j].Text = ">>";

                    }
                    else buttons[i, j].Text = "<<";
                    //cell[i, j].Click += new EventHandler(this.btnEvent_Click);
                    buttons[i, j].Enabled = false;

                    Controls.Add(buttons[i, j]);
                    x += 480;
                }
                y += 80;
            }
        
        }
        */

        //ask for account number
        private void askAcc_num()
        {
            //display field to enter data
            Label lbl_ask = new Label();


            lbl_ask.Text = "Enter account number\n";
            lbl_ask.Location = new Point(130, 100);
            lbl_ask.Font = new Font("ariel", 10);
            lbl_ask.Size = new Size(150, 20);

            enteracc.Location = new Point(120, 140);
            enteracc.Size = new Size(160, 50);
            panel1.Controls.Add(lbl_ask);
            panel1.Controls.Add(enteracc);

            //if data is available move to the enter handler


        }

        //checks wether the account number entered is correct.


        //ask for user pin if account available
        private void askpin()
        {
            enterpin.Text = string.Empty;
            entred_pin = "";
            Label ask = new Label();


            ask.Text = "Enter your pin\n";
            ask.Location = new Point(130, 100);
            ask.Font = new Font("ariel", 10);
            ask.Size = new Size(150, 20);

            enterpin.Location = new Point(125, 150);
            enterpin.Size = new Size(100, 50);
            panel1.Controls.Add(ask);
            panel1.Controls.Add(enterpin);





        }


        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            panel1.Enabled = Enabled;

        }
        //display options
        private void options()
        {
            panel1.BackColor = Color.DodgerBlue;
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 2; j++)
                {
                    option[i, j] = new Label();
                    option[i, j].ForeColor = Color.White;
                    option[i, j].BackColor = Color.Black;
                    option[i, j].AutoSize = false;
                    option[i, j].Location = new Point(150, 30);
                    option[i, j].TextAlign = ContentAlignment.MiddleCenter;
                    option[i, j].SetBounds(70 + (50 * i), 30 + (50 * j), 100, 40);
                    //Lbl[i, j].Size = new System.Drawing.Size(50, 50);
                    option[i, j].Font = new Font("Arial", 9, FontStyle.Bold);
                    //Lbl[i, j].Click += new EventHandler(this.Lbl_Click);
                    panel1.Controls.Add(option[i, j]);


                }
            }
            option[0, 0].Text = "check Balance";
            option[0, 0].Location = new Point(10, 10);



            option[1, 0].Text = "Withdraw cash";
            option[1, 0].Location = new Point(10, 95);

            option[2, 0].Text = "Deposit cash";
            option[2, 0].Location = new Point(10, 170);

            option[0, 1].Text = "prefferences";
            option[0, 1].Location = new Point(240, 10);


            option[1, 1].Text = "more";
            option[1, 1].Location = new Point(240, 95);

            option[2, 1].Text = "";
            option[2, 1].Location = new Point(240, 180);

        }


        private int withdraw_disp()
        {

            Label disp = new Label();
            disp.Text = "How much do you want to withdraw";
            disp.Location = new Point(100, 100);
            panel1.BackColor = Color.DodgerBlue;
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 2; j++)
                {
                    w_disp[i, j] = new Label();
                    w_disp[i, j].ForeColor = Color.Black;
                    w_disp[i, j].BackColor = Color.White;
                    w_disp[i, j].AutoSize = false;
                    w_disp[i, j].Location = new Point(150, 30);
                    w_disp[i, j].TextAlign = ContentAlignment.MiddleCenter;
                    w_disp[i, j].SetBounds(70 + (50 * i), 30 + (50 * j), 100, 40);
                    //Lbl[i, j].Size = new System.Drawing.Size(50, 50);
                    w_disp[i, j].Font = new Font("Arial", 9, FontStyle.Bold);
                    //Lbl[i, j].Click += new EventHandler(this.Lbl_Click);


                    panel1.Controls.Add(w_disp[i, j]);
                }
            }
            w_disp[0, 0].Text = "£5";
            w_disp[0, 0].Location = new Point(10, 10);



            w_disp[1, 0].Text = "£10";
            w_disp[1, 0].Location = new Point(10, 95);

            w_disp[2, 0].Text = "£20";
            w_disp[2, 0].Location = new Point(10, 170);

            w_disp[0, 1].Text = "£50";
            w_disp[0, 1].Location = new Point(240, 10);


            w_disp[1, 1].Text = "£100";
            w_disp[1, 1].Location = new Point(240, 95);

            w_disp[2, 1].Text = "custom";
            w_disp[2, 1].Location = new Point(240, 180);
            return amount_withdraw;
        }
        public Account checkbankacc(int result)
        {

            for (int i = 0; i < this.acc.Length; i++)
            {
                if (acc[i].getAccountNum() == result)
                {
                    //account found
                    askpin();
                    return acc[i];

                }
                else
                {//clear panel  and let user know that account number entered is wrong.
                    Console.WriteLine("account unavailable");
                    panel1.Controls.Clear();
                    Label noaccount = new Label();
                    noaccount.Text = "Account unavailable\n";
                    noaccount.ForeColor = Color.Red;
                    noaccount.Location = new Point(130, 100);
                    noaccount.Font = new Font("ariel", 10);
                    noaccount.Size = new Size(150, 20);
                    panel1.Controls.Add(noaccount);
                    askAcc_num();
                }
            }
            return null;
        }
        //button for selection

        private void button1_Click(object sender, EventArgs e)
        {

        }
        private void button2_Click(object sender, EventArgs e)
        {

        }
        private void button3_Click(object sender, EventArgs e)
        {

        }
        private void button4_Click(object sender, EventArgs e)
        {

        }
        private void button5_Click(object sender, EventArgs e)
        {

        }
        private void button6_Click(object sender, EventArgs e)
        {
            button6.Enabled = false;
        }
        //intager 0-9 clear and enter 

        //clear x
        private void button16_Click(object sender, EventArgs e)
        {

            enteracc.Clear();
            enterpin.Clear();
            this.inputText = "";
        }
        //2
        private void button8_Click(object sender, EventArgs e)
        {
            this.enteracc.Text = "";
            this.enterpin.Text = "";
            inputText += "2";

            this.enteracc.Text += inputText;

            entred_pin += "2";
            this.enterpin.Text = entred_pin;
        }
        //1
        private void button7_Click(object sender, EventArgs e)
        {
            this.enteracc.Text = "";
            this.enterpin.Text = "";
            inputText += "1";
            this.enteracc.Text += inputText;
            entred_pin += "1";
            this.enterpin.Text = entred_pin;
        }
        //3
        private void button9_Click(object sender, EventArgs e)
        {
            this.enteracc.Text = "";
            this.enterpin.Text = "";
            inputText += "3";
            this.enteracc.Text += inputText;
            entred_pin += "3";
            this.enterpin.Text = entred_pin;
        }
        //4
        private void button10_Click(object sender, EventArgs e)
        {
            this.enteracc.Text = "";
            this.enterpin.Text = "";
            inputText += "4";
            this.enteracc.Text += inputText;
            entred_pin += "4";
            this.enterpin.Text = entred_pin;
        }
        //5
        private void button11_Click(object sender, EventArgs e)
        {
            this.enteracc.Text = "";
            this.enterpin.Text = "";
            inputText += "5";
            this.enteracc.Text += inputText;
            entred_pin += "5";
            this.enterpin.Text = entred_pin;
        }
        //6
        private void button12_Click(object sender, EventArgs e)
        {
            this.enteracc.Text = "";
            this.enterpin.Text = "";
            inputText += "6";
            this.enteracc.Text += inputText;
            entred_pin += "6";
            this.enterpin.Text = entred_pin;
        }
        //7
        private void button13_Click(object sender, EventArgs e)
        {
            this.enteracc.Text = "";
            this.enterpin.Text = "";
            inputText += "7";
            this.enteracc.Text += inputText;
            entred_pin += "7";
            this.enterpin.Text = entred_pin;
        }
        //8
        private void button14_Click(object sender, EventArgs e)
        {
            this.enteracc.Text = "";
            this.enterpin.Text = "";
            inputText += "8";
            this.enteracc.Text += inputText;
            entred_pin += "8";
            this.enterpin.Text = entred_pin;
        }
        //9
        private void button15_Click(object sender, EventArgs e)
        {
            this.enteracc.Text = "";
            this.enterpin.Text = "";
            inputText += "9";
            this.enteracc.Text += inputText;
            entred_pin += "9";
            this.enterpin.Text = entred_pin;

        }
        //0
        private void button17_Click(object sender, EventArgs e)
        {
            this.enteracc.Text = "";
            this.enterpin.Text = "";
            inputText += "0";
            this.enteracc.Text += inputText;

            entred_pin += "0";
            this.enterpin.Text = entred_pin;
        }
        //Enter
        private void button18_Click(object sender, EventArgs e)
        {
            /*   if (!authentication)//not authenticated
               {
                   if (inputText == "")
                   {
                       askAcc_num();
                   }
                   //check if both are valid
                   if (inputText != "" && entred_pin != "")
                   {
                       for (int i = 0; i < accounts; i++)
                       {
                           int se = int.Parse(inputText);
                           checkbankacc(se);
                           panel1.Controls.Clear();
                           var xv = int.Parse(entred_pin);

                           if (acc[i].checkPin(xv))
                           {
                               authentication = true;
                               i = accounts;
                           }
                       }
                   }
                   //not valid
                   if (!authentication)
                   {
                       askAcc_num();
                   }
                   //go to display options
                   else if(authentication==true)
                   {
                       options();
                   }

               }
            */
        }
    }
        public class Account
        {

            private int bal;
            private int pin;
            private int accountNum;

            public Account(int bal, int pin, int accountNum)
            {
                this.bal = bal;
                this.pin = pin;
                this.accountNum = accountNum;
            }

            //getter and setter functions for balance
            public int getBalance()
            {
                return bal;
            }
            public void setBalance(int newBalance)
            {
                this.bal = newBalance;
            }

            public Boolean decrementBalance(int amount)
            {
                if (this.bal > amount)
                {
                    bal -= amount;
                    return true;
                }
                else
                {
                    return true;
                }
            }

            public int getAccountNum()
            {
                return accountNum;
            }

            public Boolean checkPin(int pinEntered)
            {
                if (pinEntered == pin)
                {


                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        class AtmSim
        {
            public Account[] acc;

            public Account activeAccount = null;
            private ATM prog;



            public AtmSim(Account[] acc)
            {
                this.acc = acc;
                prog = new ATM();
             
            }


          




            public void checkbal()
            {
                Label bal = new Label();
                bal.Location = new Point();
                bal.Text = " £" + activeAccount.getBalance();
                prog.panel1.Controls.Clear();
                prog.panel1.Controls.Add(bal);
            }
            public void withdraw(int amount)
            {
                int amountx;
                if (amount > 0)
                {
                    activeAccount.decrementBalance(amount);

                    Console.WriteLine("withdrawal succesful");

                }

            }
            public void deposit(int depo)
            {
                if (depo > 0)
                {
                    activeAccount.setBalance(+depo);
                }
            }

            public void prefferences()
            {
            }

            public void more()
            {
            }

        }
    

}
